﻿using SECS;
using SECS.S1;
using SECS.S10;
using SECS.S2;
using SECS.S7;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace WpfSECSSerivce
{
    /// <summary>
    /// MainWindow.xaml 的互動邏輯
    /// </summary>
    public partial class MainWindow : Window
    {
        public SECSService m_SECSService=new SECSService();
        private DispatcherTimer Timer;
        public MainWindow()
        {
            
            InitializeComponent();

        }
        private void Window_Initialized(object sender, EventArgs e)
        {
           
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
           
            //Recive CallBack事件

            m_SECSService.CIM_On_Line_ReciveCallback = CIM_On_Line_RECIVE;//CIM_OnLine_Sequence 15.3.1 CIM連線流程

            m_SECSService.CIM_Off_Line_ReciveCallback = CIM_Off_Line_RECIVE;
            m_SECSService.Current_Process_Program_Directory_ReciveCallback = Current_Process_Program_Directory_ReciveCallback;
            m_SECSService.Recipe_Parameter_Query_ReciveCallback = Recipe_Parameter_Query_ReciveCallback;
            m_SECSService.Last_Modification_DateTime_Recipe_ReciveCallback = Last_Modification_DateTime_Recipe_ReciveCallback;
            m_SECSService.Date_And_Time_ReciveCallback = Date_And_Time_ReciveCallback;
            m_SECSService.Lot_Process_Data_Transfer_ReciveCallback = Lot_Process_Data_Transfer_ReciveCallback;
            m_SECSService.Remote_Command_ReciveCallback = Remote_Command_ReciveCallback;
            m_SECSService.Lot_Cancel_Request_ReciveCallback = Lot_Cancel_Request_ReciveCallback;
            m_SECSService.WIP_Data_Query_ReciveCallback = WIP_Data_Query_ReciveCallback;
            m_SECSService.Terminal_Display_Multi_ReciveCallback = Terminal_Display_Multi_ReciveCallback;
            //Show Alarm 事件
            SECSService.Show_Alarm_Event = Show_Alarm_Event;
            Timer = new DispatcherTimer();
            Timer.Interval = TimeSpan.FromMilliseconds(1000);

            Timer.Tick += UpdateUI;
            Timer.Start();
        }
        private void UpdateUI(object sender, EventArgs e)
        {
            if (m_SECSService.Connected)
            {
                EllipseConnect.Fill = new SolidColorBrush(Color.FromArgb(255, 255, 0, 0));
            }
            else
            {
                EllipseConnect.Fill = new SolidColorBrush(Color.FromArgb(255, 0, 0, 255));
            }

            if (SECSService._CIM_OnLine == RMS.CIM_OffLine)
            {
                if (CboRMS.SelectedIndex != 1)
                {
                    CboRMS.SelectedIndex = 1;
                }
            }
            if (SECSService._CIM_OnLine == RMS.CIM_OnLine)
            {
                if (CboRMS.SelectedIndex != 0)
                {
                    CboRMS.SelectedIndex = 0;
                }
            }


            if (SECSService._EQ_InLine == EQMS.EQ_OffLine)
            {
                if (CboEQMS.SelectedIndex != 1)
                {
                    CboEQMS.SelectedIndex = 1;
                }
            }
            if (SECSService._EQ_InLine == EQMS.EQ_InLine)
            {
                if (CboEQMS.SelectedIndex != 0)
                {
                    CboEQMS.SelectedIndex = 0;
                }
            }
            if (SECSService._EQStatus == MCSTATUS.Idle)
            {
                if (CboMCSTATUS.SelectedIndex != 0)
                {
                    CboMCSTATUS.SelectedIndex = 0;
                }
            }
            if (SECSService._EQStatus == MCSTATUS.Running)
            {
                if (CboMCSTATUS.SelectedIndex != 1)
                {
                    CboMCSTATUS.SelectedIndex = 1;
                }
            }
            if (SECSService._EQStatus == MCSTATUS.Down)
            {
                if (CboMCSTATUS.SelectedIndex != 2)
                {
                    CboMCSTATUS.SelectedIndex = 2;
                }
            }


        }



      
        /// <summary>
        /// 顯示對話框，時需要改紅字、蜂鳴器與紅色燈號閃爍，確認後關閉(Thread)
        ///1.S2F21 $CANCEL 
        ///2.S1F15 CIM OffLine 
        ///3.S1F17 CIM OnLine 
        ///4.SECS T9(Conversation Timeout) TimeOut，SECSService Thread 45秒後會自動發送
        ///5.S7 F71 Glass Process Data Request NG
        ///6.S10F5 TID = 1
        /// </summary>
        /// <param name="Msg"></param>
        public void Show_Alarm_Event(string Msg)
        {
            //使用Invoke Show Message
            Dispatcher.Invoke(() => MessageBox.Show(Msg));
            //Tower Red
            //buzz

        }
        private void btnShow_Alarm_Event_Click(object sender, RoutedEventArgs e)
        {
            SECSService.Show_Alarm_Event = Show_Alarm_Event;
        }

        private void btnOnline_Summary_Status_Report_Click(object sender, RoutedEventArgs e)
        {
            string CPPID = "PPID";
            ALMS alarm = ALMS.No_Alarm;
            List<EQ_Status> EQ_StatusList = new List<EQ_Status>();
            EQ_Status status = new EQ_Status();
            status.EQStatus = MCSTATUS.Idle;
            status.EQPSub = MCSUBST.NoSubStatus;
            
            EQ_StatusList.Add(status);

            List<Recive_Glass_Status> Cassette_StatusList = new List<Recive_Glass_Status>();

            Recive_Glass_Status Glass_Status = new Recive_Glass_Status();

            Glass_Status.CASID = "CASID";
            Glass_Status.CHGID = "CHGID";
            Cassette_StatusList.Add(Glass_Status);
            m_SECSService.Online_Summary_Status_Report(CPPID, alarm, EQ_StatusList, Cassette_StatusList);
        }

        private void btnCIM_OnLine_Click(object sender, RoutedEventArgs e)
        {
            m_SECSService.CIM_OnLine();
        }

        private void btnCIM_OffLine_Click(object sender, RoutedEventArgs e)
        {
            m_SECSService.CIM_OffLine();
        }
        private void btnCIM_OnLine_Request_Click(object sender, RoutedEventArgs e)
        {
            m_SECSService.OnLine_Request();
        }
        private void btnEQ_Status_Report_Click(object sender, RoutedEventArgs e)
        {
            m_SECSService.EQ_Status_Report(EQMS.EQ_InLine, MCSTATUS.Idle);
        }

        private void CboEQMS_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CboEQMS.SelectedIndex==0)
            {
                SECSService._EQ_InLine = SECS.EQMS.EQ_InLine;
            }
            else
            {
                SECSService._EQ_InLine = SECS.EQMS.EQ_OffLine;
            }
            if (m_SECSService == null)
            {

            }
            else
            {
                m_SECSService.EQ_Status_Report(SECSService._EQ_InLine, MCSTATUS.Idle);
            }
        }

        private void CboRMS_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CboRMS.SelectedIndex == 0)
            {
                SECSService._CIM_OnLine = SECS.RMS.CIM_OnLine;
            }
            else
            {
                SECSService._CIM_OnLine = SECS.RMS.CIM_OffLine;
            }
        }

        private void CboMCSTATUS_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CboMCSTATUS.SelectedIndex==2)
            {
                SECSService._EQStatus = SECS.MCSTATUS.Down;
            }
            else if (CboMCSTATUS.SelectedIndex == 0)
            {
                SECSService._EQStatus = SECS.MCSTATUS.Idle;
            }
            else if (CboMCSTATUS.SelectedIndex == 1)
            {
                SECSService._EQStatus = SECS.MCSTATUS.Running;
            }
            if (m_SECSService == null)
            {

            }
            else
            {
                m_SECSService.EQ_Status_Report(SECSService._EQ_InLine, SECSService._EQStatus);
            }
        }

        private void btnHeart_Beat_Click(object sender, RoutedEventArgs e)
        {
            //SECS Service每隔180s會主動發一次
            m_SECSService.m_S2F25.SECS_Post();
            if (m_SECSService.CheckPostComplete(m_SECSService.m_S2F25))
            {
                MessageBox.Show("Recive S2F26 OK");
            }

        }

        private void btnAlarm_Report_Click(object sender, RoutedEventArgs e)
        {
            List<Recive_Glass_Status> Recive_Glass_StatusList = new List<Recive_Glass_Status>();
            Recive_Glass_Status Glsss_Status = new Recive_Glass_Status();
            Glsss_Status.CASID = "Casse1";
            Glsss_Status.CHGID = "Lot ID1";
            Recive_Glass_StatusList.Add(Glsss_Status);
            Glsss_Status = new Recive_Glass_Status();
            Glsss_Status.CASID = "Casse2";
            Glsss_Status.CHGID = "Lot ID2";
            Recive_Glass_StatusList.Add(Glsss_Status);
            m_SECSService.Alarm_Report(0x01, 1000, "AutoFocus Unit Disconnect", true, Recive_Glass_StatusList);

        }

        private void btnAlarm_Release_Click(object sender, RoutedEventArgs e)
        {
            m_SECSService.Alarm_Release();
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            m_SECSService.Dispose();
        }

        private void btnUpdateSV_Value_Click(object sender, RoutedEventArgs e)
        {
            
            int Result = m_SECSService.Update_SV_Value(3003, DateTime.Now.ToString("yyyyMMddHHmmss"));
            //return UnKnow VID = 9999
            Result = m_SECSService.Update_SV_Value(9999, DateTime.Now.ToString("yyyyMMddHHmmss"));
        }

        private void btnEvent_Report_Click(object sender, RoutedEventArgs e)
        {
            int Result=m_SECSService.Event_Report(1005);//CEID = 1005 return 0
            Result = m_SECSService.Event_Report(9999);//CEID = 9999 Unkonw return 1
        }

        private void btnGlass_Receive_Complete_Report_Click(object sender, RoutedEventArgs e)
        {
            m_SECSService.Glass_Receive_Complete_Report("GLASSDATA1", "GLASSID1", "PPID1");

        }

        private void btnGlass_Process_Data_Report_Click(object sender, RoutedEventArgs e)
        {
            Dictionary<string, string> InspectData = new Dictionary<string, string>();
            InspectData.Add("R", "200");
            InspectData.Add("G", "200");
            InspectData.Add("B", "200");

            m_SECSService.Glass_Process_Data_Report(1, 1, "LotId1", "Casse1", "1", "01", "Operator", "0", "PPID1", "0", "T", "GLASSID1", InspectData);
        }

        private void btnGlass_Send_Complete_Report_Click(object sender, RoutedEventArgs e)
        {
            m_SECSService.Glass_Send_Complete_Report("GLASSData1", "GLASSID1", "PPID1", DateTime.Now.ToString("yyyyMMddHHmmss"), DateTime.Now.ToString("yyyyMMddHHmmss"));

        }

        private void btnLot_Process_Data_Report_Click(object sender, RoutedEventArgs e)
        {
            Dictionary<string, string> InspectData = new Dictionary<string, string>();
            InspectData.Add("R", "200");
            InspectData.Add("G", "200");
            InspectData.Add("B", "200");
            List<string> PPIDList = new List<string>();
            PPIDList.Add("PPID1");
            PPIDList.Add("PPID2");

            m_SECSService.Lot_Process_Data_Report(1, 1, 0, "LotID1", "Csset1", "Operator", "1", "1", "0", "T", PPIDList, InspectData);
        }

        private void btnInline_DMQC_Judge_Data_Report_Click(object sender, RoutedEventArgs e)
        {
            m_SECSService.Inline_DMQC_Judge_Data_Report("GLASSData1", "GLASSID1", "NN  ");


        }

        private void btnGlass_Interface_Signal_Report_Click(object sender, RoutedEventArgs e)
        {
            List<InertfaceSignal> InertfaceSignalList = new List<InertfaceSignal>();
            InertfaceSignal signal = new InertfaceSignal();
            signal.GLSDATA = "GLASSDATA1";
            signal.GLSIF = "0000000F";
            InertfaceSignalList.Add(signal);
            signal = new InertfaceSignal();
            signal.GLSDATA = "GLASSDATA2";
            signal.GLSIF = "0000000A";
            InertfaceSignalList.Add(signal);
            m_SECSService.Glass_Interface_Signal_Report(InertfaceSignalList);
        }

        private void btnWIP_Data_Report_Click(object sender, RoutedEventArgs e)
        {

            List<WIPData> WIPDataList = new List<WIPData>();
            WIPData wipdata = new WIPData();

            wipdata.POS_NAME = "POS_NAME1";
            wipdata.PCBID = "PCBID1";
            wipdata.GLSDATA = "GLSDATA1";
            WIPDataList.Add(wipdata);
            wipdata = new WIPData();
            wipdata.POS_NAME = "POS_NAME2";
            wipdata.PCBID = "PCBID2";
            wipdata.GLSDATA = "GLSDATA2";
            WIPDataList.Add(wipdata);
            m_SECSService.WIP_Data_Report(WIPDataList);
        }

        private void btnGlass_Process_Data_Request_Click(object sender, RoutedEventArgs e)
        {
            m_SECSService.Glass_Process_Data_Request("Operator", "GLASSID1");
        }

        private void btnGlass_Data_Erase_Report_Click(object sender, RoutedEventArgs e)
        {
            m_SECSService.Glass_Data_Erase_Report("GLASSData1", "GLASSID1");
        }

        private void btnTotal_Recipe_ID_Report_Click(object sender, RoutedEventArgs e)
        {
            List<string> PPIDList = new List<string>();
            PPIDList.Add("PPID1");
            PPIDList.Add("PPID2");
            m_SECSService.Total_Recipe_ID_Report(PPIDList);
        }

        private void btnDate_And_Time_Request_Click(object sender, RoutedEventArgs e)
        {
            m_SECSService.Date_And_Time_Request();
        }

        private void btnOperator_ID_Report_Click(object sender, RoutedEventArgs e)
        {
            m_SECSService.Operator_ID_Report("Operator");
        }

        private void btnTerminal_Request_Click(object sender, RoutedEventArgs e)
        {
            m_SECSService.Terminal_Request(0x01, "Message");
        }
        /// <summary>
        /// 15.10.2 Online Sequence from Host
        /// </summary>
        /// <param name="s1F17"></param 
        public void CIM_On_Line_RECIVE(S1F17 s1F17)
        {

            //s1F17.ONLACK = 0;
            //避免socket 堵塞 所以SECS使用用Task.Run 注意一下UI
            CIM_OnLine_Sequence();

        }

        private void btnCIM_On_Line_ReciveCallback_Click(object sender, RoutedEventArgs e)
        {
            m_SECSService.CIM_On_Line_ReciveCallback = CIM_On_Line_RECIVE;
        }

        public void CIM_Off_Line_RECIVE(S1F15 s1F15)
        {

            s1F15.OFLACK = 0;

        }
        private void btnCIM_Off_Line_ReciveCallback_Click(object sender, RoutedEventArgs e)
        {
         
            m_SECSService.CIM_Off_Line_ReciveCallback = CIM_Off_Line_RECIVE;
        }

        public void Current_Process_Program_Directory_ReciveCallback(S7F19 s1F19)
        {

            s1F19.PPIDList.Add("PPID1");
            s1F19.PPIDList.Add("PPID2");
        }
        private void btnCurrent_Process_Program_Directory_ReciveCallback_Click(object sender, RoutedEventArgs e)
        {
            m_SECSService.Current_Process_Program_Directory_ReciveCallback = Current_Process_Program_Directory_ReciveCallback;
        }

        public void Recipe_Parameter_Query_ReciveCallback(S7F3 s7F3)
        {
            //recive s7F3.PPID PPID Host會送過來，所以只須接收，使用PPID查參數
            string PPID = s7F3.PPID;//接收PPID
            //find parameters
            s7F3.ParameterData.Add("Param1", "value1");
            s7F3.ParameterData.Add("Param2", "value2");

            s7F3.ACKC7 = 0;//00H:Commad accepted default:0

        }
        private void btnRecipe_Parameter_Query_ReciveCallback_Click(object sender, RoutedEventArgs e)
        {
            m_SECSService.Recipe_Parameter_Query_ReciveCallback = Recipe_Parameter_Query_ReciveCallback;


        }

        public void Last_Modification_DateTime_Recipe_ReciveCallback(S7F67 s7F67)
        {
            string PPID = s7F67.PPID;//接收PPID
            //找尋PPID 

            //回復修改日期
            s7F67.DATETIME = DateTime.Now.ToString("yyyyMMddHHmmss");

            s7F67.ACKC7 = 0;//回復結果00H: OK 04H: PPID Not Define Others: Other Error

        }
        private void btnLast_Modification_DateTime_Recipe_ReciveCallback_Click(object sender, RoutedEventArgs e)
        {
            m_SECSService.Last_Modification_DateTime_Recipe_ReciveCallback = Last_Modification_DateTime_Recipe_ReciveCallback;
        }

        public void Date_And_Time_ReciveCallback(S2F31 s2F31)
        {

            //日期 字串
            //s2F31.DATETIME
            //因為程式已經更改時間了
            //所以直接可用DateTime.Now 更新
            s2F31.TIACK = 0;
        }
        private void btnDate_And_Time_ReciveCallback_Click(object sender, RoutedEventArgs e)
        {
            m_SECSService.Date_And_Time_ReciveCallback = Date_And_Time_ReciveCallback;
        }

        public void Lot_Process_Data_Transfer_ReciveCallback(S7F65 s7F65)
        {
            //接收資料
            //s7F65.m_Lot_Process_Data.RCODE
            //s7F65.m_Lot_Process_Data.CASID
            //s7F65.m_Lot_Process_Data.CHGID

            //s7F65.m_Lot_Process_Data.m_ProcessEQ.PROCTOOL 
            //接收slot 資料
            for (int ii = 0; ii < s7F65.m_Lot_Process_Data.m_ProcessEQ.SlotList.Count; ii++)
            {
                if (s7F65.m_Lot_Process_Data.m_ProcessEQ.SlotList[ii].PROCFLAG == "1")  //0: No Process 1: Process
                {

                }

            }
            //回復結果
            s7F65.ACKC7 = 0;
        }
        public void Lot_Process_Data_Transfer_ReciveCallback_NG(S7F65 s7F65)
        {
            //接收資料
            //s7F65.m_Lot_Process_Data.RCODE
            //s7F65.m_Lot_Process_Data.CASID
            // s7F65.m_Lot_Process_Data.CHGID

            //s7F65.m_Lot_Process_Data.m_ProcessEQ.PROCTOOL 
            //接收slot 資料
            for (int ii = 0; ii < s7F65.m_Lot_Process_Data.m_ProcessEQ.SlotList.Count; ii++)
            {
                if (s7F65.m_Lot_Process_Data.m_ProcessEQ.SlotList[ii].PROCFLAG == "1")  //0: No Process 1: Process
                {

                }

            }
            //回復結果
            s7F65.ACKC7 = 1;
        }
        private void btnLot_Process_Data_Transfer_ReciveCallback_Click(object sender, RoutedEventArgs e)
        {

            m_SECSService.Lot_Process_Data_Transfer_ReciveCallback = Lot_Process_Data_Transfer_ReciveCallback;
        }

        public void Remote_Command_ReciveCallback(S2F21 s2F21)
        {
            //s2F21.RCMD
            /*
            1~14 Byte: <CHGID> *Lot ID
            15~20 Byte: <CASID> *Cassette ID
            21 Byte: <PORTID> *Port ID
            22~28 Byte: <RCMD> *Equipment Remote Command“$START”, “$CANCEL”, “$SUSPND”, “$RESUME”
            29~30 Byte: < PNLCNT> *Glass Number
            */
            string Lot_ID=s2F21.RCMD.Substring(0, 14);//Lot ID
            string Cassette_ID = s2F21.RCMD.Substring(14, 6);//Cassette ID
            string Port_ID = s2F21.RCMD.Substring(20, 1);//Port ID
            //"$START", "$CANCEL", "$SUSPND", "$RESUME" 字串7個字元 會有空白
            string RemoteCommand = s2F21.RCMD.Substring(21, 7);//Equipment Remote Command
            //PNLCNT
            string Glass_Number = s2F21.RCMD.Substring(28, 2);//Glass Number
            if (s2F21.SAVFLG == "Y")
            {
                //Save s2F21.RTXT
            }
            /*
             00H: Command accepted 
             01H: Command not defined
             02H: Cannot execute now 
             03H: Parameter Error
            */
            //回復結果
            s2F21.CMDA = 0;

        }


        private void btnRemote_Command_ReciveCallback_Click(object sender, RoutedEventArgs e)
        {
            m_SECSService.Remote_Command_ReciveCallback = Remote_Command_ReciveCallback;
        }
        public void Lot_Cancel_Request_ReciveCallback(S7F73 s7F73)
        {
            //s7F73.CASID;
            //s7F73.CHGID;
            //s7F73.PORTNO

            //Port Data 
            // s7F73.PORTNO

            for (int ii = 0; ii < s7F73.LotDataList.Count; ii++)
            {
                //s7F73.LotDataList[ii].SLOTNO;//Slot ID
                //s7F73.LotDataList[ii].PCBID; //Glass ID

            }

        }
        private void btnLot_Cancel_Request_ReciveCallback_Click(object sender, RoutedEventArgs e)
        {
            m_SECSService.Lot_Cancel_Request_ReciveCallback = Lot_Cancel_Request_ReciveCallback;
        }

        public void WIP_Data_Query_ReciveCallback(S1F87 s1F87)
        {
           //將資料加入WIP
            WIPData wipdata = new WIPData();
            wipdata.POS_NAME = "POS_NAME1";
            wipdata.PCBID = "PCBID1";
            wipdata.GLSDATA = "GLSDATA1";
            s1F87.WIPDataList.Add(wipdata);
            wipdata = new WIPData();
            wipdata.POS_NAME = "POS_NAME2";
            wipdata.PCBID = "PCBID2";
            wipdata.GLSDATA = "GLSDATA2";
            s1F87.WIPDataList.Add(wipdata);


        }
        private void btnWIP_Data_Query_ReciveCallback_Click(object sender, RoutedEventArgs e)
        {
            m_SECSService.WIP_Data_Query_ReciveCallback = WIP_Data_Query_ReciveCallback;
        }

        public void Terminal_Display_Multi_ReciveCallback(S10F5 s10F5)
        {
            /*
             00H: Broadcast Message
             01H: Warning Message
            */
            //s10F5.TID 
            //s10F5.TEXT//訊息
            s10F5.ACKC10 = 0;
            //TID==1 Show_Alarm_Event 會秀訊息
            // MessageBox.Show(s10F5.TEXT);
        }
        private void btnTerminal_Display_Multi_ReciveCallback_Click(object sender, RoutedEventArgs e)
        {
            m_SECSService.Terminal_Display_Multi_ReciveCallback = Terminal_Display_Multi_ReciveCallback;
        }
        /// <summary>
        /// 上線動作，包含CIM 主動上線
        /// </summary>
        public void CIM_OnLine_Sequence()
        {

            //On Line Request
            m_SECSService.OnLine_Request();
            if(!m_SECSService.CheckPostComplete(m_SECSService.m_S1F1))
            {
                m_SECSService.CIM_OffLine();
                return;
            }
            //DateTime DownLoad
            m_SECSService.Date_And_Time_Request();

            if (!m_SECSService.CheckPostComplete(m_SECSService.m_S2F17))
            {
                m_SECSService.CIM_OffLine();
                return;
            }
            //Update Summary Status              
            btnOnline_Summary_Status_Report_Click(null, null);
            if (!m_SECSService.CheckPostComplete(m_SECSService.m_S1F69))
            {
                m_SECSService.CIM_OffLine();
                return;
            }
            //Update All Recipe
            btnTotal_Recipe_ID_Report_Click(null, null);
            if (!m_SECSService.CheckPostComplete(m_SECSService.m_S1F95))
            {
                m_SECSService.CIM_OffLine();
                return;
            }

            m_SECSService.CIM_OnLine();
        }
        /// <summary>
        /// 15..3 Equiipmentt Mode Change Sequence
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCIM_Online_Sequence_Click(object sender, RoutedEventArgs e)
        {
            CIM_OnLine_Sequence();
        }



        /// <summary>
        /// 15.3.3 CIM Off-Line Sequence
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void btnCIM_Offline_Sequence_Click(object sender, RoutedEventArgs e)
        {
            btnCIM_OffLine_Click(sender, e);
        }
        /// <summary>
        /// 15.3.4 Equipment turns into EQ Off-Line Mode Sequence
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnEQ_Offline_Sequence_Click(object sender, RoutedEventArgs e)
        {

            m_SECSService.EQ_Status_Report(EQMS.EQ_OffLine, MCSTATUS.Idle);

            if (!m_SECSService.CheckPostComplete(m_SECSService.m_S1F65))
            {
                return;
            }
            m_SECSService.EQ_Status_Report(EQMS.EQ_OffLine, MCSTATUS.Down);
            
        }
        /// <summary>
        /// 15.3.5 Equipment turns into EQ In-Line Mode Sequence
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnEQ_Inline_Sequence_Click(object sender, RoutedEventArgs e)
        {
            m_SECSService.EQ_Status_Report(EQMS.EQ_InLine, MCSTATUS.Down);

            if (!m_SECSService.CheckPostComplete(m_SECSService.m_S1F65))
            {
                return;
            }
            m_SECSService.EQ_Status_Report(EQMS.EQ_InLine, MCSTATUS.Idle);
           
        }

        /// <summary>
        /// 15.4.2 Lot glasses process cancel to EQ abnormal sequence
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnLot_glasses_process_normal_sequence_Click(object sender, RoutedEventArgs e)
        {
            m_SECSService.Lot_Process_Data_Transfer_ReciveCallback = Lot_Process_Data_Transfer_ReciveCallback;
            //會觸發T9 Timeout 的等待45s時間
            m_SECSService.Remote_Command_ReciveCallback = Remote_Command_ReciveCallback;
            //接收到 Remote_Command_ReciveCallback 直接進入等待玻璃進入狀況，T9 Timeout 取消
            // Glass Recive Complete

            // process loop start
            {
                m_SECSService.EQ_Status_Report(EQMS.EQ_InLine, MCSTATUS.Idle);

                btnGlass_Receive_Complete_Report_Click(sender, e);
                //檢查收到結果
                if (!m_SECSService.CheckPostComplete(m_SECSService.m_S6F91))
                {
                    return;
                }
                m_SECSService.EQ_Status_Report(EQMS.EQ_InLine, MCSTATUS.Running);
                //Prcoess 啟動

                //檢測完成上傳資料

                //檢測完成上報Judge資料
                btnInline_DMQC_Judge_Data_Report_Click(sender, e);

                //檢測完成上報資料
                btnGlass_Process_Data_Report_Click(sender, e);

                //UnLoad上報資料
                btnGlass_Send_Complete_Report_Click(sender, e);
                //Process 結束
                m_SECSService.EQ_Status_Report(EQMS.EQ_InLine, MCSTATUS.Idle);
            }
            //process loop end
            //整個Lot完成後
            btnLot_Process_Data_Report_Click(sender, e);

        }
        /// <summary>
        /// 15.4.4 Lot glasses process cancel to EQ abnormal sequence
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnLot_glasses_process_cancel_PPID_NG_sequence_Click(object sender, RoutedEventArgs e)
        {
            m_SECSService.Lot_Process_Data_Transfer_ReciveCallback = Lot_Process_Data_Transfer_ReciveCallback_NG;
            //接收到 Remote_Command_ReciveCallback 檢查異常 ACKC7 !=0;
            m_SECSService.Remote_Command_ReciveCallback = Remote_Command_ReciveCallback;
            
        }
        /// <summary>
        /// 15.4.4 Lot glasses process cancel to EQ abnormal sequence
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnLot_glasses_process_cancel_PPID_OK_sequence_Click(object sender, RoutedEventArgs e)
        {
            m_SECSService.Lot_Process_Data_Transfer_ReciveCallback = Lot_Process_Data_Transfer_ReciveCallback;
            //接收到 Remote_Command_ReciveCallback 檢查異常 ACKC7 ==0;
            m_SECSService.Remote_Command_ReciveCallback = Remote_Command_ReciveCallback;
        }
        /// <summary>
        /// 15.5.1 Single glasses process normal sequence
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSingle_glass_rocess_sequence_Click(object sender, RoutedEventArgs e)
        {
            //向Host詢問Glass Data
            btnGlass_Process_Data_Request_Click(sender, e);
            //會觸發T9 Timeout 的等待45s時間
            m_SECSService.Lot_Process_Data_Transfer_ReciveCallback = Lot_Process_Data_Transfer_ReciveCallback;
            //會觸發T9 Timeout 的等待45s時間
            m_SECSService.Remote_Command_ReciveCallback = Remote_Command_ReciveCallback;
            //接收到 Remote_Command_ReciveCallback 直接進入等待玻璃進入狀況，T9 Timeout 取消
            // Glass Recive Complete


            m_SECSService.EQ_Status_Report(EQMS.EQ_InLine, MCSTATUS.Idle);

            btnGlass_Receive_Complete_Report_Click(sender, e);
            //檢查收到結果
            if (!m_SECSService.CheckPostComplete(m_SECSService.m_S6F91))
            {
                return;
            }
            m_SECSService.EQ_Status_Report(EQMS.EQ_InLine, MCSTATUS.Running);
            //Prcoess 啟動

            //檢測完成上傳資料

            //檢測完成上報Judge資料
            btnInline_DMQC_Judge_Data_Report_Click(sender, e);

            //檢測完成上報資料
            btnGlass_Process_Data_Report_Click(sender, e);

            //UnLoad上報資料
            btnGlass_Send_Complete_Report_Click(sender, e);
            //Process 結束
            m_SECSService.EQ_Status_Report(EQMS.EQ_InLine, MCSTATUS.Idle);


        }
        /// <summary>
        /// 15.5.2 Single glass process cancel to EQ abnormal sequence (S7F66<>0)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSingle_glass_process_cancel_PPCID_NG_sequence_Click(object sender, RoutedEventArgs e)
        {
            // 向Host詢問Glass Data
            btnGlass_Process_Data_Request_Click(sender, e);
            m_SECSService.Lot_Process_Data_Transfer_ReciveCallback = Lot_Process_Data_Transfer_ReciveCallback_NG;
            //接收到 Remote_Command_ReciveCallback 檢查異常 ACKC7 !=0;
            m_SECSService.Remote_Command_ReciveCallback = Remote_Command_ReciveCallback;
            //接收到 Remote_Command_ReciveCallback 直接進入等待玻璃進入狀況
           
        }
        /// <summary>
        /// 15.5.3 Single glasses process cancel to EQ abnormal sequence
        /// 15.5.4 Single glasses process cancel to EQ abnormal sequence
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSingle_glass_process_cancel_PPCID_OK_sequence_Click(object sender, RoutedEventArgs e)
        {
            // 向Host詢問Glass Data
            btnGlass_Process_Data_Request_Click(sender, e);
            m_SECSService.Lot_Process_Data_Transfer_ReciveCallback = Lot_Process_Data_Transfer_ReciveCallback;
            //接收到 Remote_Command_ReciveCallback 檢查異常 ACKC7 ==0;
            m_SECSService.Remote_Command_ReciveCallback = Remote_Command_ReciveCallback;
            //接收到 Remote_Command_ReciveCallback 直接進入等待玻璃進入狀況

        }
        /// <summary>
        /// 15..7 Add/Dellete Recipe IID normal sequence 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnChange_Recipe_normal_sequence_Click(object sender, RoutedEventArgs e)
        {
            btnTotal_Recipe_ID_Report_Click(sender, e);
        }
        /// <summary>
        /// 15.9.1 Glass Receive Complete Sequence
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnGlass_Receive_Complete_Sequence_Click(object sender, RoutedEventArgs e)
        {
            btnGlass_Receive_Complete_Report_Click(sender, e);
        }
        /// <summary>
        /// 15.9.2 Glass Send Complete Sequence
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnGlass_Send_Complete_Sequence_Click(object sender, RoutedEventArgs e)
        {
            btnGlass_Send_Complete_Report_Click(sender, e);
        }

        /// <summary>
        /// 15.6.1 Equipment Alarm can be Auto-Recover (Light Alarm)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnLight_Alarm_sequence_Click(object sender, RoutedEventArgs e)
        {
            //回報機台現在狀態
            m_SECSService.EQ_Status_Report(SECSService._EQ_InLine, SECSService._EQStatus);

            //發出輕微異常
            List<Recive_Glass_Status> Recive_Glass_StatusList = new List<Recive_Glass_Status>();
            Recive_Glass_Status Glsss_Status = new Recive_Glass_Status();
            Glsss_Status.CASID = "Casse1";
            Glsss_Status.CHGID = "Lot ID1";
            Recive_Glass_StatusList.Add(Glsss_Status);
            Glsss_Status = new Recive_Glass_Status();
            Glsss_Status.CASID = "Casse2";
            Glsss_Status.CHGID = "Lot ID2";
            Recive_Glass_StatusList.Add(Glsss_Status);
            m_SECSService.Alarm_Report(0x01, 2000, "Key in Valid Error", false, Recive_Glass_StatusList);

            //作業處理完成後

            //釋放異常
            m_SECSService.Alarm_Release();

            //回報機台現在狀態
            m_SECSService.EQ_Status_Report(SECSService._EQStatus);

        }

        /// <summary>
        /// 15.6.2 Equipment Alarm need to Stop Recover (Serious Alarm)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSerious_Alarm_sequence_Click(object sender, RoutedEventArgs e)
        {
            //回報機台現在狀態
            m_SECSService.EQ_Status_Report(SECSService._EQ_InLine, SECSService._EQStatus);

            //發出嚴重異常
            List<Recive_Glass_Status> Recive_Glass_StatusList = new List<Recive_Glass_Status>();
            Recive_Glass_Status Glsss_Status = new Recive_Glass_Status();
            Glsss_Status.CASID = "Casse1";
            Glsss_Status.CHGID = "Lot ID1";
            Recive_Glass_StatusList.Add(Glsss_Status);
            Glsss_Status = new Recive_Glass_Status();
            Glsss_Status.CASID = "Casse2";
            Glsss_Status.CHGID = "Lot ID2";
            Recive_Glass_StatusList.Add(Glsss_Status);
            m_SECSService.Alarm_Report(0x01, 1000, "AutoFocus Unit Disconnect", true, Recive_Glass_StatusList);

            //更改機台現在狀態
            m_SECSService.EQ_Status_Report(MCSTATUS.Down);
            //無法處理時 CIM OffLine
            m_SECSService.CIM_OffLine();
            //作業處理完成後 重新連線
            btnCIM_Online_Sequence_Click(sender, e);
           
            //釋放異常
            m_SECSService.Alarm_Release();

            //改變機台現在狀態
            m_SECSService.EQ_Status_Report(MCSTATUS.Idle);
        }

        private void EllipseConnect_MouseDown(object sender, MouseButtonEventArgs e)
        {
            //關閉SECS 連線
            m_SECSService.Close();
           
            //重開SECS 連線
            m_SECSService.Open();
        }

    
    }
}
